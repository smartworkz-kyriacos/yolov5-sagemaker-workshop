---
title: Requirements
weight: "10"
disableToc: true
---
Dankzij de eenvoud van Hugo is deze pagina zo leeg als dit thema eisen stelt.

Download gewoon de nieuwste versie van [Hugo binary (&gt; 0.25)](https://gohugo.io/getting-started/installing/) fvoor uw besturingssysteem (Windows, Linux, Mac): zo eenvoudig is het.

![Magic](/en/basics/requirements/images/magic.gif?classes=shadow)
