---
title: Basis
weight: 5
pre: "<b>1. </b>"
chapter: true
---
### Hoofdstuk 1

# Basis

Ontdek waar dit Hugo-thema over gaat en de kernconcepten erachter.
